//
//  Tab2ViewController.swift
//  test1
//
//  Created by shaoting on 16/4/20.
//  Copyright © 2016年 9elephas. All rights reserved.
//

import UIKit

class Tab2ViewController: UIViewController {

  @IBOutlet var btn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
      btn.addTarget(self, action: #selector(Tab2ViewController.btnClick), forControlEvents: .TouchUpInside)
        // Do any additional setup after loading the view.
    }
   func btnClick(){
    let urlString = "test2://"
    let url = NSURL(string: urlString)
    UIApplication.sharedApplication().openURL(url!)
   }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
